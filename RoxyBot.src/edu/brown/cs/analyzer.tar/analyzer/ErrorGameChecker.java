package edu.brown.cs.analyzer;

import java.io.FileReader;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.Iterator;

public class ErrorGameChecker {
	public static ArrayList<Integer> checkErrorGame (String directory, ArrayList<String> agent) { try {
		Iterator<String> iter = agent.iterator();
		ArrayList<Integer> ret = new ArrayList<Integer>();
		while (iter.hasNext()) {
			String agentname = iter.next();
			System.out.print(agentname + "\t");
			LineNumberReader r = new LineNumberReader(new FileReader(directory + agentname + "/a.out"));
			int gameID = 0;
			int tmp = 0;
			boolean check = false;
			String line;
			while ((line = r.readLine()) != null) {
				if (line.contains("gameID ")) {
					gameID = Integer.valueOf(line.split("gameID ")[1].split(", ")[0]);
					check = false;
				}
				
				if (line.contains("ScenarioGenerator is already running.")) {
					if (check) continue;
					System.out.print(gameID + ", ");
					ret.add(gameID);
					check = true;
					tmp ++;
				}
				
				if (line.contains("Error")) {
					if (check) continue;
					System.out.print(gameID + ", ");
					ret.add(gameID);
					check = true;
					tmp ++;
				}
			}
			System.out.println("\n\t" + tmp);
			r.close();
		}
		return ret;
	} catch (Exception e) { e.printStackTrace(); return null; } }
	
	public static void main(String[] args) {
		ArrayList<String> agent = new ArrayList<String>();
		agent.add("2000-t");
		agent.add("2000-f");
		agent.add("2002-t");
		agent.add("2002-f");
		agent.add("saa-t");
		agent.add("saa-f");
		agent.add("amu");
		agent.add("smu");
		String directory = "/pro/roxybot/2005/sjlee/experiment/8agent.attac.vs.nonattac.061026/";
		System.out.println(directory);
		checkErrorGame(directory, agent); /**/
		
		/*
		agent.clear();
		agent.add("2000-f1");
		agent.add("2000-f2");
		agent.add("evm1");
		agent.add("evm2");
		agent.add("smu1");
		agent.add("smu2");
		agent.add("2000-t1");
		agent.add("2000-t2");
		String directory = "/pro/roxybot/2005/sjlee/experiment/4agent.2/";
		System.out.println(directory);
		checkErrorGame(directory, agent); /**/
	}
}
