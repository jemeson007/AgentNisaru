package edu.brown.cs.analyzer;

import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.text.DecimalFormat;
import java.util.Arrays;

import props.Misc;

/**
 * this is an abbreviated parser, which only reads event informations
 */

public class EventParser {
    public double[][]			eventBidHistory;// [auction][halfminute] // Ask > Bid
    public double[][]			eventAskHistory;// [auction][halfminute]
    public double[][]			eventTrsHistory;// [auction][halfminute]
    private String[]			auctionId;     	// [28]
    private String[]			agentId;		// [8]
    private String[]			agentName;		// [8]
    private long				startTime;
    
	private static final DecimalFormat formatter = new DecimalFormat("000.00");
    
    public EventParser() { }
    
    private void init() {
		eventBidHistory  = new double[12][19];
		eventAskHistory  = new double[12][19];
		eventTrsHistory  = new double[12][19];
		for (int i = 0; i < 12; i++) Arrays.fill(eventAskHistory[i], 200);
		for (int i = 0; i < 12; i++) Arrays.fill(eventTrsHistory[i], 999);
		
		auctionId = new String[28];
		agentId   = new String[8];
		agentName = new String[8];
	}
	
	public void parse (String url) throws IOException { 
		Misc.myassert(url.endsWith(".log"));
		
		init();
		
		FileReader reader = new FileReader(url);
		LineNumberReader lineReader = new LineNumberReader(reader);
		String line = "";
		int id, time;
		
		/**********
		 * agent Id
		 */
		reader = new FileReader(url);
		lineReader = new LineNumberReader(reader);
		line = lineReader.readLine();
		startTime = Long.valueOf(line.split(",")[0]);
		
		id = 0;
		while (id < 8) {
			if (line.contains(",a,")) {
				String[] fragment = line.split(",");
				agentId[id] = fragment[3];
				agentName[id] = fragment[2];
				id++;
			}
			
			line = lineReader.readLine();
		}
		
		/************
		 * Auction Id
		 */
		reader = new FileReader(url);
		lineReader = new LineNumberReader(reader);
		line = lineReader.readLine();
		
		id = 0;
		while (id < 28) {
			if (line.contains(",u,")) {
				String[] fragment = line.split(",");
				auctionId[id] = fragment[2];
				id++;
			}
			
			line = lineReader.readLine();
		}
		
		// good hotel and bad hotel changed
		for (int i = 0; i < 4; i++) {
			String temp = auctionId[8+i];
			auctionId[8+i] = auctionId[12+i];
			auctionId[12+i] = temp;
		}
		
		/***************
		 * Event History
		 */
		for (int auctionNo = 16; auctionNo < 28; auctionNo++) {
			reader = new FileReader(url);
			lineReader = new LineNumberReader(reader);
			line = lineReader.readLine();
			
			while (line != null) {
				// t,buyerID, sellerID, auctionID, quantity, price [, transactionID]
				if (line.contains(",t,") && line.contains(auctionId[auctionNo])) {
					final String[] fragment = line.split(",");
					System.out.println(line);
					System.out.println(fragment[0]);
					System.out.println(Double.valueOf(fragment[6]));
					if (fragment[1].equals("t")) {
						final long currTime = Long.valueOf(fragment[0]);
						time = (int) ((currTime - startTime) / 30);
						eventTrsHistory[auctionNo-16][time] = Double.valueOf(fragment[6]);
					}
				}
				
				if (line.contains(",q,".concat(auctionId[auctionNo]).concat(","))) {
					final String[] fragment = line.split(",");
					final long currTime = Long.valueOf(fragment[0]);
					time = (int) ((currTime - startTime) / 30);
					
					eventAskHistory[auctionNo-16][time] = Double.valueOf(fragment[3]);
					eventBidHistory[auctionNo-16][time] = Double.valueOf(fragment[4]);
					
					if (eventAskHistory[auctionNo-16][time] == 0 || eventAskHistory[auctionNo-16][time] > 200) 
						eventAskHistory[auctionNo-16][time] = 200;
					if (eventBidHistory[auctionNo-16][time] > 200) {
						eventBidHistory[auctionNo-16][time] = 200;
					}
					
					for (int i = time + 1; i <= 18; i++) {
						eventAskHistory[auctionNo-16][i] = eventAskHistory[auctionNo-16][time];
						eventBidHistory[auctionNo-16][i] = eventBidHistory[auctionNo-16][time];						
					}
				}
				line = lineReader.readLine();
			}
			
			double tmp = eventTrsHistory[auctionNo-16][18];
			for (int t = 53; t > 0; t--) {
				if (eventTrsHistory[auctionNo-16][t] == 999) {
					eventTrsHistory[auctionNo-16][t] = tmp;
				} else {
					tmp = eventTrsHistory[auctionNo-16][t];
				}
			}
			eventTrsHistory[auctionNo-16][0] = tmp;
		}
	}
	
	private int getAuctionId (String s) {
		for (int a = 0; a < 28; a++) {
			if (auctionId[a].equals(s)) {
				return a;
			}
		}
		
		return -1;
	}
	
	public int getAgentIdFromName (String s) {
		for (int a = 0; a < 8; a++) {
			if (agentName[a].equals(s)) {
				return a;
			}
		}
		
		return -1; // when 'auction'
	}
	
	public int getAgentId (String s) {
		for (int a = 0; a < 8; a++) {
			if (agentId[a].equals(s)) {
				return a;
			}
		}
		
		return -1; // when 'auction'
	}
	
	
	public String toString() {
		String ret = "";
		
		ret += "EventBidHistory \n";
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 18; j++) {
				ret += formatter.format(eventBidHistory[i][j]) + " ";
			}
			ret += "\n";
		}
		ret += "\n";

		ret += "EventAskHistory \n";
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 18; j++) {
				ret += formatter.format(eventAskHistory[i][j]) + " ";
			}
			ret += "\n";
		}
		ret += "\n";


		ret += "EventTrsHistory \n";
		for (int i = 0; i < 12; i++) {
			for (int j = 0; j < 18; j++) {
				ret += formatter.format(eventTrsHistory[i][j]) + " ";
			}
			ret += "\n";
		}
		ret += "\n";
		
		return ret;
	}
	
	public static void main (String[] args) {
		for (int i = 1; i<=1; i++) {
			try {			
				EventParser p = new EventParser();
				p.parse("/pro/roxybot/2005/sjlee/history/applet" + i + ".log");
				System.out.println(p);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
