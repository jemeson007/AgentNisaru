package edu.brown.cs.analyzer;

import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 * @author sjlee
 * @since  Sep 30, 2005
 */

public class StatList {
	public String agentName;
	public double minimum, quartile1, median, quartile3, maximum; // five-number summary
	public double sigma; // standard deviation
	public double mu;    // mean
	public int size;     // size
	private static final DecimalFormat formatter = new DecimalFormat("####.00");
	
	public ArrayList<Double> originalList;
	public ArrayList<Double> sortedList;
	
	public StatList (String agent, ArrayList<Double> list) {
		agentName = agent;
		originalList = list;
		
		// sorting
		sortedList = new ArrayList<Double>();
		for (int i = 0; i < list.size(); i++) {
			double value = list.get(i);

			sortedList.add(value);
			
			for (int j = 0; j < sortedList.size()-1; j++) {
        		if (sortedList.get(j) > value) {
        			for (int k = sortedList.size()-1; k > j; k--)
        				sortedList.set(k, sortedList.get(k-1));
        			
        			sortedList.set(j, value);
        			break;
        		}
        	}
		}
		
		// five-number summary
		size = originalList.size();
		/*
		minimum = sortedList.get(0);
		maximum = sortedList.get(size-1);
		quartile1 = sortedList.get((int)Math.floor(size/4));
		quartile3 = sortedList.get((int)Math.floor(size*3/4)+1);
		if (size % 2 == 0)
			median = ( sortedList.get(size/2-1) + sortedList.get(size/2) ) / 2;
		else
			median = sortedList.get((size-1)/2);
		*/
		
		// mean
		mu = 0;
		for (int i = 0; i < size; i++) {
			mu += (list.get(i) - mu) / (i+1);
		}
		
		// standard deviation
		sigma = 0;
		for (int i = 0; i < size; i++) {
			sigma += (mu - list.get(i)) * (mu - list.get(i)) / (size-1);
		}
		sigma = Math.sqrt(sigma);
	}
	
	public double getVariance() { return sigma * sigma; }
	public double getStandardDeviation() { return sigma; }
	public double getMean() { return mu; }
	public int getSize() {return size; }
	
	
	public String toString() {
		String ret = "";
		ret += agentName;
		// ret += "\n";
		
		/*
		// five-number summary
		ret += "  (min,Q1,median,Q3,max) = ";
		ret += "(" + formatter.format(minimum)
			+ "," + formatter.format(quartile1)
			+ "," + formatter.format(median)
			+ "," + formatter.format(quartile3)
			+ "," + formatter.format(maximum)
			+ ")";
		ret += "\n";
		*/
		
		// mu and sigma
		ret += "  mean = " + formatter.format(mu);
		ret += "  standard deviation = " + formatter.format(sigma);
		ret += "  standard error = " + formatter.format(sigma / Math.sqrt(size)) + "\n";
		// ret += "  size = " + size;
		return ret;
	}
}
