package edu.brown.cs.analyzer;

/**
 * @author sjlee
 * @since  Sep 30, 2005
 */

import java.util.ArrayList;

import props.Misc;

public class Statistics {
	// http://statpages.org/pdfs.html
	public static double getPValue (double t, int n) {
		t = Math.abs(t);
		double w = t / Math.sqrt(n);
		double th = Math.atan(w);
		double PiD2 = Math.PI / 2;
		if (n == 1) return 1 - th/PiD2;
		double sth = Math.sin(th);
		double cth = Math.cos(th);
		if (n%2 == 1) return 1-(th+sth*cth*StatCom(cth*cth,2,n-3,-1))/PiD2;
		else return 1-sth*StatCom(cth*cth,1,n-3,-1);
	}
	
	private static double StatCom(double q, int i, int j, int b) {
	    double zz=1;
	    double z=zz;
	    
	    for (int k = i; k <= j; k += 2) {
	    	zz = zz * q * k / (k-b);
	    	z = z+zz;
	    }
	    
	    return z;
	}
	
	// http://mathworld.wolfram.com/Pairedt-Test.html
	public static double pairedTTest (StatList a, StatList b) {
		Misc.myassert(a.size == b.size);
		ArrayList<Double> difference = new ArrayList<Double>();
		for (int i = 0; i < a.size; i++) {
			difference.add(a.originalList.get(i) - b.originalList.get(i));
		}
		StatList c = new StatList(a.agentName + "-" + b.agentName, difference);
		return c.mu * Math.sqrt(c.size) / c.sigma;
	}
	
	public static double tTest (StatList a, StatList b) {
		// standard error of the difference
		double se = Math.sqrt(a.getVariance() / a.getSize() + b.getVariance() / b.getSize());
		double t = Math.abs(a.getMean() - b.getMean()) / se;
		return t;
	}
	
	/**
	 * @param a : arraylist
	 * @param b : arraylist
	 * @param n : number of samples from list
	 * @return P ( x > 0 ) while mu > 0 of list (agent a's score - agent b's score).
	 */
	public static double confidenceTest(StatList a, StatList b) {
		if (a.size != b.size) System.out.println("## Statistics.confidenceTest:: list size of a and b are different!");
		
		int n = a.size;
		
		ArrayList<Double> list = new ArrayList<Double>();
		for (int i = 0; i < a.size; i++) {
			// Since a[gameId] and b[gameId] is dependent, we should use unsorted list.
			if (a.mu > b.mu)
				list.add(i, a.originalList.get(i) - b.originalList.get(i));
			else 
				list.add(i, b.originalList.get(i) - a.originalList.get(i));		
		}
		
		StatList statList = new StatList("score difference between " + a.agentName + " and " + b.agentName, list);
		Misc.println(statList);
		
		return zStat(statList.mu, statList.sigma, n);
	}
	
	/**
	 * Two-Sample z Statistic
	 * 
	 * @param mu    : mean of list
	 * @param sigma : standard deviation of list
	 * @param n     : number of samples from list
	 * @return P(x>0), while x is mean of n random samples from list
	 */
	static public double zStat(double mu, double sigma, int n) {
		if (sigma < 0) System.out.println("## Statistics.zStat::sigma is " + sigma + " < 0. something is wrong!");

		double ret = 0;
		double zScore = - mu / Math.sqrt( sigma * sigma / n );
		Misc.println("zscore : " + zScore);
		Misc.println("size : " + n);
		ret = cdf_norm(zScore);
		
		return zScore;
	}
	
	/**
	 * Cumulative Density Function
	 *
	 * Pseudocode is copied from the following:
	 * http://groups.google.ca/group/sci.math.num-analysis/msg/621569190cdb2680
	 * 
	 * @param z : z score
	 * @return possibility
	 */
	static public double cdf_norm (double z) {
		final double PREC = 0.00005;
		double a, b, c, term, sum;
		
		a = b = 1;
		c = sum = term = z;
    
		if (Math.abs(z) > 8) return 0.5 * z / Math.abs(z);
		
		for (int i = 1; Math.abs(term) > PREC; i++)
		{
			a += 2;
            b *= -2 * i;
            c *= z * z;
            term = c / (a * b);
            sum += term;
		}
		
		return sum / Math.sqrt(2 * Math.PI);
	} 
	
	public static void main(String[] args) {
		
	}
}
