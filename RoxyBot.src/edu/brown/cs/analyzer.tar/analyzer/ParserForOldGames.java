package edu.brown.cs.analyzer;

import edu.brown.cs.modeler.Parser;
import edu.brown.cs.tac.Constants;
import edu.brown.cs.tacds.*;
import java.io.FileReader;
import java.io.IOException;
import java.io.LineNumberReader;
import java.text.DecimalFormat;
import java.util.Arrays;

import props.Misc;

/**
 * @author sjlee
 * @since Jun 16, 2006
 * 
 * Old games (2003 and before) has different format. 
 * I just temporalized it for predictionEvaluator.
 * auctionID update is also changed.
 * flightHistory and hotelHistory is different from its real definition.
 * Note that the game time is different (not 9 minutes).
 */
public class ParserForOldGames extends Parser {
	public double getMinFlight (int i) {
		return flightMinimum[i];
	}
	
	public double getHotelClosingPrice(int i) {
		if (i >= 8) i -= 8;
		return hotelClosingPrice[i];
	}
	
	private void init() {
		preferences			= new Preference[8][8];
		allocations				= new Allocation[8];
		hotelClosingPrice	= new double[8];
		flightMinimum			= new double[8];
		flightHistory			= new double[8][1];
		hotelHistory			= new double[8][1];
		score						= new double[8];
		utility   					= new double[8];
		
		auctionId = new String[28];
		agentID   = new String[8];
		agentName = new String[8];
	}
	
	private void readAgentID() throws IOException {
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		String line = lineReader.readLine();
		int id = 0;
		while (id < 8 && line != null) {
			if (line.contains(",a,")) {
				String[] fragment = line.split(",");
				agentID[id] = fragment[3];
				agentName[id] = fragment[2];
				id++;
			}
			
			line = lineReader.readLine();
		}
		if (line == null) Misc.warn("readAgentID : id " + id);
	}
	
	private void readAuctionID() throws IOException {
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		String line = lineReader.readLine();
		while (line != null) {
			if (line.contains(",u,")) {
				String[] fragment = line.split(",");
				int type = Integer.valueOf(fragment[3]);
				int day = Integer.valueOf(fragment[4]);
				if (type == 1) day--; // outflight
				int id = type * 4 + day - 1;
				
				auctionId[id] = fragment[2];
			}
			line = lineReader.readLine();
		}
		
		// Good hotel and bad hotel are reversed.
		for (int i = 0; i < 4; i++) {
			String temp = auctionId[8+i];
			auctionId[8+i] = auctionId[12+i];
			auctionId[12+i] = temp;
		}
	}
	
	private void readPreference() throws IOException {
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine()) {
			String[] fragment = line.split(",");
			if (!fragment[1].equals("c")) continue;
			int agent = this.getAgentID(fragment[3]);
			
			for (int c = 0; c < 8; c++) {
				int index = 4 + c * 6;
				int in  = Integer.valueOf(fragment[index]);
				int out = Integer.valueOf(fragment[index+1]);
				int hp  = Integer.valueOf(fragment[index+2]);
				int e1p = Integer.valueOf(fragment[index+3]);
				int e2p = Integer.valueOf(fragment[index+4]);
				int e3p = Integer.valueOf(fragment[index+5]);
				
				preferences[agent][c] = new Preference(in, out, hp, e1p, e2p, e3p);
			}
		}
	}
	
	private void readCollection() throws IOException {
		Misc.myassert(false);
	}

	private void readAllocation() throws IOException {
		for (int agent = 0; agent < 8; agent++) {
			allocations[agent] = new Allocation();
		}
		
		// l, gameID, agentID, in, out, hotel, e1, e2, e3 [, more client allocations]
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine()) {
			String[] fragment = line.split(",");
			if (!fragment[1].equals("l")) continue;
			int agent = this.getAgentID(fragment[3]);
			
			for (int c = 0; c < 8; c++) {
				int index = 4 + c * 6;
				int in  = Integer.valueOf(fragment[index]);
				int out = Integer.valueOf(fragment[index+1]);
				int hp  = Integer.valueOf(fragment[index+2]);
				int e1p = Integer.valueOf(fragment[index+3]);
				int e2p = Integer.valueOf(fragment[index+4]);
				int e3p = Integer.valueOf(fragment[index+5]);
				
				allocations[agent].setTravelPackage(c, new TravelPackage(in, out, hp, e1p, e2p, e3p));
			}
		}
	}

	private void readScore() throws IOException {
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine()) {
			String[] fragment = line.split(",");
			
			if (fragment[1].equals("s")) {
				int agentID = getAgentID(fragment[3]);
				if (agentID == -1) continue;
				score[agentID] = Double.valueOf(fragment[4]);
				utility[agentID] = Double.valueOf(fragment[6]);
			}
		}
	}
	
	private void readQuote() throws IOException {
		for (int a = 0; a < 8; a++) {
			flightMinimum[a] = Constants.MAX_PRICE_FOR_FLIGHT;
		}
		
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine()) {
			String[] fragment = line.split(",");
			if (!fragment[1].equals("q")) continue;

			long time = Long.valueOf(fragment[0]);
			int auction = this.getAuctionID(fragment[2]);
			double askPrice = Double.valueOf(fragment[3]);	// buy with this price

			switch(Constants.auctionType(auction)) {
			case Constants.TYPE_FLIGHT:
				flightMinimum[auction] = Math.min(flightMinimum[auction], askPrice);
				if (time - startTime < 10) {
					flightHistory[auction][0] = askPrice;
					Misc.myassert(askPrice <= 400 && askPrice >= 250);
				}
				break;
			}
		}
	}
	
	private void readClosing() throws IOException {
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		for (String line = lineReader.readLine(); line != null; line = lineReader.readLine()) {
			String[] fragment = line.split(",");
			if (!fragment[1].equals("q")) continue;
			
			int auction = this.getAuctionID(fragment[2]);
			if (Constants.auctionType(auction) != Constants.TYPE_HOTEL) continue;
			
			hotelClosingPrice[auction-8] = Double.valueOf(fragment[3]);
		}
	}
	
	private void readBid() throws IOException {
		Misc.myassert(false);
	}

	private void readTransaction() throws IOException {
		Misc.myassert(false);
	}
	
	public void parse (String url) throws IOException { 
		Misc.myassert(url.endsWith(".log"));
		
		init();
		
		this.url = url;
		LineNumberReader lineReader = new LineNumberReader(new FileReader(url));
		String line = lineReader.readLine();
		startTime = Long.valueOf(line.split(",")[0]);
		
		// Always, read these two method first.
		this.readAgentID();
		this.readAuctionID();
		
		this.readScore();
		this.readClosing();
		this.readPreference();
		this.readAllocation();
		this.readQuote();
	}
	
	private int getAuctionID (String s) {
		for (int a = 0; a < 28; a++) {
			if (auctionId[a].equals(s)) {
				return a;
			}
		}
		
		return -1;
	}
	
	public int getAgentIDFromName (String s) {
		for (int a = 0; a < 8; a++) {
			if (agentName[a].equals(s)) {
				return a;
			}
		}
		
		return -1; // when 'auction'
	}
	
	public int getAgentID (String s) {
		for (int a = 0; a < 8; a++) {
			if (agentID[a].equals(s)) {
				return a;
			}
		}
		
		return -1; // when 'auction'
	}
		
	public String toString() {
		String ret = "";
		
		int maxAuction = 16;
		
		/*
		Misc.println("agentID\tagentName\tscore\tutility");
		for (int i = 0; i < 8; i++) {
			Misc.println(agentID[i] + "\t"
					+ agentName[i] + "\t" 
					+ formatter.format(score[i]) + "\t" 
					+ formatter.format(utility[i]));
		} /**/
		
		Misc.println("HotelClosingPrice");
		for (int i = 0; i < 8; i++) {
			Misc.print(formatter.format(this.getHotelClosingPrice(i)) + "\t");
		}
		Misc.println(); /**/
		
		return ret;
	}
	
	public String getAgentWithTab(int i) {
		if (agentName[i].length() < 8) return agentName[i] + "\t\t";
		return agentName[i] + "\t";
	}
	
	public static void main (String[] args) {
		try {			
			ParserForOldGames p = new ParserForOldGames();
			p.parse("/pro/roxybot/2005/sjlee/data/history/final03/applet6.log");
			Misc.println(p);
		} catch (IOException e) {	e.printStackTrace(); }
	}
}
