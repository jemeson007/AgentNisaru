package edu.brown.cs.analyzer;

import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

import edu.brown.cs.modeler.Parser;
import edu.brown.cs.tacds.Preference;
import edu.brown.cs.tacds.TravelPackage;

import props.Misc;

/*
 * @author sjlee
 * @since  Sep 17, 2005
 */
public class Scorer {
	private Parser parser = new Parser();
	private static DecimalFormat formatter = new DecimalFormat("0.00");
	
	private StatList[] scoreLists, utilityLists, costLists;
	private double[] hotelBidQuantity, hotelBidPrice;
	private double[] hotelWonQuantity, hotelWonPrice;
	private double[] hotelUnusedQuantity, hotelUnusedPrice;
	private double[] flightWonQuantity, flightWonPrice;
	private double[] eventBuyQuantity, eventBuyPrice;
	private double[] eventSellQuantity, eventSellPrice;
	private double[] eventUnusedQuantity;
	private double[] eventBonus, hotelBonus, tripPenalty;
	private double[] nullPackage;
	private double[] tripLength;
	
	public Scorer (int t) {
		scoreLists 		= new StatList[t];
		utilityLists 		= new StatList[t];
		costLists 		= new StatList[t];
		hotelBidPrice 			= new double[t];
		hotelBidQuantity 	= new double[t];
		hotelWonPrice 		= new double[t];
		hotelWonQuantity 	= new double[t];
		hotelUnusedPrice	= new double[t];
		hotelUnusedQuantity = new double[t];
		flightWonPrice 		= new double[t];
		flightWonQuantity 	= new double[t];
		eventBuyQuantity 	= new double[t];
		eventBuyPrice		= new double[t];
		eventSellQuantity	= new double[t];
		eventSellPrice		= new double[t];
		eventUnusedQuantity = new double[t];
		eventBonus			= new double[t];
		hotelBonus			= new double[t];
		tripPenalty			= new double[t];
		tripLength				= new double[t];
		nullPackage			= new double[t];
	}
	
	public void downloadFromHost (final String host, final int gameID) { try {
		Runtime rt = Runtime.getRuntime();
		Process process = null;
		String exec = "";
		int exitVal;
		
		// example : wget http://tac1.sics.se:8080/history/423/applet.log.gz;
		process = rt.exec("rm ./applet.log.gz");
		exitVal = process.waitFor();
		
		exec = "wget http://" + host + ":8080/history/" + gameID + "/applet.log.gz";
		process = rt.exec(exec);
		exitVal = process.waitFor();
		
		// example : gzip -d applet.log.gz;
		exec = "gzip -d applet.log.gz";
		process = rt.exec(exec);
		exitVal = process.waitFor();
		
		// example : mv applet.log ./history/applet423.log;
		exec = "mv applet.log ./history/applet" + gameID + ".log -f";
		process = rt.exec(exec);
		exitVal = process.waitFor();
	} catch (Throwable t) { 	t.printStackTrace(); } }

	/**
	 * It also writes to the file.
	 */
	public void readFromLogs (
			int		 fromGameNo,
			int		 toGameNo, 
			String   directoryToRead, // it should end with '/'
			String   directoryToWrite, 
			String[] agentNames) {
		
		final Vector<Double>[] scores 	= new Vector[agentNames.length];
		final Vector<Double>[] utilities 	= new Vector[agentNames.length];
		final Vector<Double>[] costs 		= new Vector[agentNames.length];
		for (int i = 0; i < agentNames.length; i++) {
			scores[i] = new Vector<Double>();
			utilities[i] = new Vector<Double>();
			costs[i] = new Vector<Double>();
		}
		
		String str = "";
		
		// HEADER
		str += "# read	: " + directoryToRead + "\n";
		str += "# range   : " + "[" + fromGameNo + "~" + toGameNo + "]" + "\n";
		str += "\n";
		
		for (int gameNo = fromGameNo; gameNo <= toGameNo; gameNo++) {
			// TODO This part is used to remove bad games. 
			// you have to touch this part every time you run the scorer. 
			int[] badGame = {
						660, 
						11, 12, 13, 14, 15, 138, 138, 406, 691, 697, 704, 709, 713, 722, 724, 725, 729, 744, 746, 751, 753, 830, 
						8, 9, 529, 530, 
						7, 11, 297, 
						13, 406, 683};
			
			boolean tmp = false;
			for (int i = 0; i < badGame.length; i++) {
				if (badGame[i] == gameNo) tmp = true;
			}
			if (tmp) continue;
			
			
			Misc.println(gameNo);
			final String fileToRead = directoryToRead + "applet" + gameNo + ".log";
			
			try {
				parser.parse(fileToRead);
			} catch (IOException e) {
				Misc.println("## Scorer.score::" + fileToRead + " doesn't exist.");
				e.printStackTrace();
				continue;
			}
			
			for (int i = 0; i < agentNames.length; i++) {
				if (agentNames.length == 4 || agentNames.length == 2) {
					for (int j = 1; j <= (8 / agentNames.length); j++) {
						final int agentID = parser.getAgentIDFromName(agentNames[i] + j);
						if (agentID == -1) continue;
						scores[i].add(parser.score[agentID]);
						utilities[i].add(parser.utility[agentID]);
						costs[i].add(parser.score[agentID] - parser.utility[agentID]);
						
						readAgentFromParser (i, agentID);
					}
				} else if (agentNames.length == 8) {
					final int agentID = parser.getAgentIDFromName(agentNames[i]);
					if (agentID == -1) continue;
					scores[i].add(parser.score[agentID]);
					utilities[i].add(parser.utility[agentID]);
					costs[i].add(parser.score[agentID] - parser.utility[agentID]);

					readAgentFromParser (i, agentID);
				}
			}
		}
		
		String scoreStr = str;
		String utilityStr = str;
		String costStr = str;
		
		for (int i = 0; i < agentNames.length; i++) {
			scoreStr += agentNames[i] + "\n";
			utilityStr += agentNames[i] + "\n";
			costStr += agentNames[i] + "\n";
			for (int j = 0; j < scores[i].size(); j++) {
				scoreStr += scores[i].get(j) + " ";
				utilityStr += utilities[i].get(j) + " ";
				costStr += costs[i].get(j) + " ";
			}
			scoreStr += "\n";
			utilityStr += "\n";
			costStr += "\n";
		}
		
		try {
			final String fileToWrite = directoryToWrite + "score.txt";
			BufferedWriter out = new BufferedWriter(new FileWriter(fileToWrite));
			out.write(scoreStr);
			out.close();
		} catch (IOException e) {	e.printStackTrace(); }
		
		try {
			final String fileToWrite = directoryToWrite + "utility.txt";
			BufferedWriter out = new BufferedWriter(new FileWriter(fileToWrite));
			out.write(utilityStr);
			out.close();
		} catch (IOException e) {	e.printStackTrace(); }

		try {
			final String fileToWrite = directoryToWrite + "cost.txt";
			BufferedWriter out = new BufferedWriter(new FileWriter(fileToWrite));
			out.write(costStr);
			out.close();
		} catch (IOException e) {	e.printStackTrace(); }
	}
	
	private void readAgentFromParser (int index, int agent) {
		for (int a = 0; a < 8; a++) {
			flightWonQuantity[index] += parser.buyQuantity[agent][a];
			flightWonPrice[index] += parser.buyPrice[agent][a];
			hotelWonQuantity[index] += parser.buyQuantity[agent][a+8];
			hotelWonPrice[index] += parser.buyPrice[agent][a+8];
			hotelBidQuantity[index] += parser.bidQuantity[agent][a+8];
			hotelBidPrice[index] += parser.bidPrice[agent][a+8];
		}
		
		for (int a = 0; a < 12; a++) {
			eventBuyPrice[index] 		+= parser.buyPrice[agent][a+16];
			eventBuyQuantity[index] 	+= parser.buyQuantity[agent][a+16];
			eventSellPrice[index] 		+= parser.sellPrice[agent][a+16];
			eventSellQuantity[index] 	+= parser.sellQuantity[agent][a+16];
		}
		
		int[] hotelUnused = new int[8];
		int eventUnused = 0;
		for (int a = 0; a < 8; a++) hotelUnused[a] = parser.collections[agent][8].owned[a+8];
		for (int a = 0; a < 12; a++) eventUnused += parser.collections[agent][8].owned[a+16];
		for (int c = 0; c < 8; c++) {
			Preference p = parser.preferences[agent][c];
			TravelPackage t = parser.allocations[agent].getTravelPackage(c);
			
			if (t.isNull()) {
				nullPackage[index]++;
				continue;
			}
			
			eventBonus[index] += p.getEventValue(t.getEventDayIndex0());
			eventBonus[index] += p.getEventValue(t.getEventDayIndex1());
			eventBonus[index] += p.getEventValue(t.getEventDayIndex2());
			eventBonus[index] += p.getEventValue(t.getEventDayIndex3());
			
			hotelBonus[index] += (t.getHotelType()==1) ? p.getHotelValue() : 0;
			tripPenalty[index] += Math.abs(p.getArrivalDate() - 1 - t.getInflightDayIndex()) * 100;
			tripPenalty[index] += Math.abs(p.getDepartureDate() - 2 - t.getOutflightDayIndex()) * 100;
			
			int out = parser.allocations[agent].getTravelPackage(c).getOutflightDayIndex(); // 0 ~ 3
			int in = parser.allocations[agent].getTravelPackage(c).getInflightDayIndex(); // 0 ~ 3
			int hotel = parser.allocations[agent].getTravelPackage(c).getHotelType();
			if (in == -1) continue;
			tripLength[index] += out - in + 1;
			for (int i = in; i <= out; i++) hotelUnused[4 * hotel + i]--;
			eventUnused -= parser.allocations[agent].getTravelPackage(c).getNumEventUsed();
		}
		for (int a = 0; a < 8; a++) Misc.myassert(hotelUnused[a] >= 0);
		Misc.myassert(eventUnused >= 0);
		for (int a = 0; a < 8; a++) {
			hotelUnusedPrice[index] += parser.hotelClosingPrice[a] * hotelUnused[a];
			hotelUnusedQuantity[index] += hotelUnused[a];
		}
		eventUnusedQuantity[index] += eventUnused;
	}
	
	public void readFromFile (final String filename) { try{
		FileReader reader = new FileReader(filename);
		LineNumberReader lineReader = new LineNumberReader(reader);
		String line = "";
		
		int count = 0;
		while (true) {
			line = lineReader.readLine();
			if (line == null) break;
			if (line.startsWith("#")) continue;
			if (line.length() == 0) continue;
			
			// At this point it should be the name of the agent
			String name = line;
			line = lineReader.readLine();
			
			// At this point it should be the scores
			String[] numbers = line.split(" ");
			
			ArrayList<Double> list = new ArrayList<Double>();
			for (int i = 0; i < numbers.length; i++) {
				if (filename.contains("cost")) {
					list.add(-Double.valueOf(numbers[i]));
				} else {
					list.add(Double.valueOf(numbers[i]));
				}
			}
			
			if (filename.contains("score"))
				scoreLists[count] = new StatList(name, list); 
			if (filename.contains("util"))
				utilityLists[count] = new StatList(name, list);
			if (filename.contains("cost"))
				costLists[count] = new StatList(name, list);
			
			count++;
		}
		
	} catch (Exception e) { e.printStackTrace(); } }

	public void runPairedTTest(String[] agentNames) {
		StatList[] scorelists = new StatList[agentNames.length];
		StatList[] utillists = new StatList[agentNames.length];
		StatList[] costlists = new StatList[agentNames.length];
		
		for (int i = 0; i < agentNames.length; i++) {
			ArrayList<Double> scores = new ArrayList<Double>();
			ArrayList<Double> utils = new ArrayList<Double>();
			ArrayList<Double> costs = new ArrayList<Double>();
			
			for (int j = 0; j < scoreLists.length; j++) {
				if (scoreLists[j].agentName.equals(agentNames[i])) {
					for (int k = 0; k < scoreLists[j].originalList.size(); k++) {
						scores.add(scoreLists[j].originalList.get(k));
						utils.add(utilityLists[j].originalList.get(k));
						costs.add(costLists[j].originalList.get(k));
					}
				}
			}
			
			scorelists[i] = new StatList(agentNames[i], scores);
			costlists[i] = new StatList(agentNames[i], costs);
			utillists[i] = new StatList(agentNames[i], utils);
		}
		
		printTables(scorelists, utillists, costlists);
	}
	
	private void printTable (StatList[] list, String str) {
		Misc.println("\\hline");
		printTableHeader(list);
		Misc.println("\\hline");
		for (int i = 0; i < list.length; i++) {
			Misc.print(getModifiedName(list[i].agentName) + "\t&");
			for (int j = 0; j < list.length; j++) {
				if (i < j) { // high
					double confidence = Statistics.getPValue(Statistics.pairedTTest(list[i], list[j]), list[i].size);
					Misc.print(formatter.format(confidence));
					if (confidence < 0.1) {
						if (list[i].mu > list[j].mu) {
							Misc.print(getModifiedName(list[i].agentName) + "\t");
						} else {
							Misc.print(getModifiedName(list[j].agentName) + "\t");
						}
					} else if (confidence < 0.5) {
						if (list[i].mu > list[j].mu) {
							Misc.print("\\scriptsize{" + getModifiedName(list[i].agentName) + "}\t");
						} else {
							Misc.print("\\scriptsize{" + getModifiedName(list[j].agentName) + "}\t");
						}
					} else {
						if (list[i].mu > list[j].mu) {
							Misc.print("\\tiny{" + getModifiedName(list[i].agentName) + "}\t");
						} else {
							Misc.print("\\tiny{" + getModifiedName(list[j].agentName) + "}\t");
						}
					}
				} else if (i > j) { // low
					double confidence = Statistics.getPValue(Statistics.pairedTTest(list[i], list[j]), list[i].size);
					
					if (confidence < 0.1) {
						if (list[i].mu < list[j].mu) {
							Misc.print(getModifiedName(list[i].agentName) + "\t");
						} else {
							Misc.print(getModifiedName(list[j].agentName) + "\t");
						}
					} else if (confidence < 0.5) {
						if (list[i].mu < list[j].mu) {
							Misc.print("\\scriptsize{" + getModifiedName(list[i].agentName) + "}\t");
						} else {
							Misc.print("\\scriptsize{" + getModifiedName(list[j].agentName) + "}\t");
						}
					} else {
						if (list[i].mu < list[j].mu) {
							Misc.print("\\tiny{" + getModifiedName(list[i].agentName) + "}\t");
						} else {
							Misc.print("\\tiny{" + getModifiedName(list[j].agentName) + "}\t");
						}
					}
				} else {
					Misc.print("\t");
				}
				if (j != list.length - 1) Misc.print("&");
			}
			Misc.println("\\\\");
		}
		Misc.println("\\hline");
	}
	
	private void printTables (StatList[] score, StatList[] value, StatList[] cost) {
		printTable(score, "score");
		printTable(value, "value");
		printTable(cost, "cost");
	}
	
	private void printTableHeader (StatList[] list) {
		Misc.print("\t");
		for (int i = 0; i < list.length; i++) {
			Misc.print("&" + getModifiedName(list[i].agentName) + "\t");
		}
		Misc.println("\\\\");
	}
	
	public void printStatistics () {
		Misc.println("agent\tscore\tutility\tcost");
		
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print(getModifiedName(scoreLists[i].agentName));
			Misc.print("\t");
			Misc.print(formatter.format(scoreLists[i].mu));
			Misc.print("\t");
			Misc.print(formatter.format(utilityLists[i].mu));
			Misc.print("\t");
			Misc.print(formatter.format(costLists[i].mu));
			Misc.println();
		}
	}
	
	public void printBidInformation () {
		int size = scoreLists[0].size;
		
		Misc.println("\\begin{table}[ht!]");
		Misc.println("\\begin{center}");
		Misc.println("\\begin{tabular}{||l||c|c|c|c|c|c|c|c|}");
		Misc.println("\\hline");
		printTableHeader(scoreLists);
		Misc.println("\\hline");
		Misc.print("\\# of Hotels Bidden\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelBidQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average of Hotels Bidden\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelBidPrice[i] / hotelBidQuantity[i]) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Hotels Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelWonQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Cost of Hotels Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelWonPrice[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average of Hotels Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelWonPrice[i] / hotelWonQuantity[i])+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Hotels Unused\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelUnusedQuantity[i] / size)+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("Cost of Hotels Unused\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelUnusedPrice[i] / size)+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Hotels Used\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(tripLength[i] / size)+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("Hotel Bonus\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(hotelBonus[i] / size)+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("Trip Penalty\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(tripPenalty[i] / size)+ "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Flights Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(flightWonQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Cost of Flights Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(flightWonPrice[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average of Flights Won\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(flightWonPrice[i] / flightWonQuantity[i]) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Events Bought\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventBuyQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Cost of Events Bought\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventBuyPrice[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average of Events Bought\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" +  formatter.format(eventBuyPrice[i] / eventBuyQuantity[i]) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Events Sold\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventSellQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Cost of Events Sold\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventSellPrice[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average of Events Sold\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" +  formatter.format(eventSellPrice[i] / eventSellQuantity[i]) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("\\# of Events Unused\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventUnusedQuantity[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Profit from Event Trading\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format((eventSellPrice[i] - eventBuyPrice[i]) / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Event Bonus\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(eventBonus[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Null Package\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(nullPackage[i] / size) + "\t");
		}
		Misc.println("\\\\");
		Misc.println("\\hline");
		Misc.print("Average Utility\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(utilityLists[i].mu) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average Cost\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(costLists[i].mu) + "\t");
		}
		Misc.println("\\\\");
		Misc.print("Average Score\t");
		for (int i = 0; i < scoreLists.length; i++) {
			Misc.print("&" + formatter.format(scoreLists[i].mu) + "\t");
		}
		Misc.println("\\\\");
		Misc.println("\\hline");
		Misc.println("\\end{tabular}");
		Misc.println("\\end{center}");
		Misc.println("\\caption{blah blah blah}");
		Misc.println("\\label{tab:blah}}");
		Misc.println("\\end{table}");
		
		Misc.println("* There are total " + size + " observations.");
	}
	
	private String getModifiedName (String s) {
		return s;
		/*
		String ret = s;
		if (s.contains("saa")) ret += "\\SAA";
		if (s.contains("amu")) ret += "\\amu";
		if (s.contains("smu")) ret += "\\smu";
		if (s.contains("2000")) ret += "2000";
		if (s.contains("2002")) ret += "2002";
		if (s.contains("-t")) ret += "$^*$";
		return ret; /**/
	}
	
	public void entertainmentKMeans() { try {
		// data is 18 dimensional vector. (ask, bid) x minute
		ArrayList<double[]> group1 = new ArrayList<double[]>();
		ArrayList<double[]> group2 = new ArrayList<double[]>();
		
		Random rand = new Random(System.currentTimeMillis());
		for (int gameNo = 1; gameNo <= 165; gameNo++) {
			if (gameNo % 16 == 0) Misc.print(".");
			final String fileToRead = "/pro/roxybot/2005/sjlee/data/history/final06/applet" + gameNo + ".log";
			parser.readAllocation = false;
			parser.readCollection = false;
			parser.readPreference = false;
			parser.readScore = false;
			parser.parse(fileToRead);
			
			for (int auc = 0; auc < 12; auc++) {
				double[] vector = new double[18];
				for (int decisec = 0; decisec < 54; decisec++) {
					double ask = parser.eventAskHistory[auc][decisec];
					double bid = parser.eventBidHistory[auc][decisec];
					vector[decisec/6] += ask / 6;
					vector[decisec/6 + 9] += bid / 6;
				}
				
				if (rand.nextBoolean()) {
					group1.add(vector);
				} else {
					group2.add(vector);
				}
			}
		}
		
		double[] oldCenter1 = getCenter(group1);
		double[] oldCenter2 = getCenter(group2);
		for (int i = 0; i < 500; i++) {
			Misc.print(i + " ");
			ArrayList<double[]> newGroup1 = new ArrayList<double[]>();
			ArrayList<double[]> newGroup2 = new ArrayList<double[]>();
			for (int j = 0; j < group1.size(); j++) {
				if (getDistance(group1.get(j), oldCenter1) < getDistance(group1.get(j), oldCenter2)) {
					newGroup1.add(group1.get(j));
				} else {
					newGroup2.add(group1.get(j));
				}
			}
			
			for (int j = 0; j < group2.size(); j++) {
				if (getDistance(group2.get(j), oldCenter1) < getDistance(group2.get(j), oldCenter2)) {
					newGroup1.add(group2.get(j));
				} else {
					newGroup2.add(group2.get(j));
				}
			}
			
			group1 = newGroup1;
			group2 = newGroup2;
			Misc.println(getDistance(oldCenter1, getCenter(group1)) + getDistance(oldCenter2, getCenter(group2)));
			
			oldCenter1 = getCenter(group1);
			oldCenter2 = getCenter(group2);
			Misc.printArray(oldCenter1);
			Misc.printArray(oldCenter2);
		}
		
	} catch (Exception e) { e.printStackTrace(); } }
	
	public double getDistance (double[] a, double[] b) {
		double ret = 0;
		for (int i = 0; i < a.length; i++) {
			ret += (a[i] - b[i]) * (a[i] - b[i]);
		}
		return Math.sqrt(ret);
	}
	
	public double[] getCenter (ArrayList<double[]> a) {
		double[] ret = new double[18];
		Iterator<double[]> iter = a.iterator();
		while (iter.hasNext()) {
			double[] d = iter.next();
			for (int i = 0; i < 18; i++) ret[i] += d[i] / a.size();
		}
		return ret;
	}
	
	public void analyzeEntertainment () { try {
		double[] averageBidByDay = new double[4];
		double[] averageBidByMinute = new double[9];
		double[] averageAskByDay = new double[4];
		double[] averageAskByMinute = new double[9];
		
		int[][] askDistribution = new int[201][9];
		int[][] bidDistribution = new int[201][9];
		
		FileWriter[] w = new FileWriter[9];
		FileWriter[] wask = new FileWriter[9];
		FileWriter[] wbid = new FileWriter[9];
		for (int i = 0; i < 9; i++) {
			w[i]= new FileWriter("/pro/roxybot/2005/sjlee/workspace/graph/eventByMinute/data" + i);
			wask[i]= new FileWriter("/pro/roxybot/2005/sjlee/workspace/graph/eventByMinute/distribution ask " + i);
			wbid[i]= new FileWriter("/pro/roxybot/2005/sjlee/workspace/graph/eventByMinute/distribution bid " + i);
		}
		
		for (int gameNo = 1; gameNo <= 165; gameNo++) {
			Misc.println(gameNo);
			final String fileToRead = "/pro/roxybot/2005/sjlee/data/history/final06/applet" + gameNo + ".log";
			
			parser.readAllocation = false;
			parser.readCollection = false;
			parser.readPreference = false;
			parser.readScore = false;
			parser.parse(fileToRead);
			
			for (int decisec = 0; decisec < 54; decisec++) {
				for (int auc = 0; auc < 12; auc++) {
					double ask = parser.eventAskHistory[auc][decisec];
					double bid = parser.eventBidHistory[auc][decisec];
					
					Misc.myassert(bid <= 200);
					Misc.myassert(ask <= 200);
					Misc.myassert(bid <= ask);
					
					averageAskByDay[auc % 4] += ask / 54 / 4 / 165;
					averageBidByDay[auc % 4] += bid / 54 / 4 / 165;
					averageAskByMinute[decisec / 6] += ask / 6 / 12 / 165;
					averageBidByMinute[decisec / 6] += bid / 6 / 12 / 165;
					
					askDistribution[(int)ask][decisec/6]++;
					bidDistribution[(int)bid][decisec/6]++;
					w[decisec / 6].write(ask + " " + bid + "\n");
				}
			}
		}
		
		for (int i = 0 ; i < 9; i++) w[i].close();
		
		for (int i = 0; i < 200; i++) {
			for (int j = 0; j < 9; j++) {
				wask[j].write(i + " " + askDistribution[i][j] + "\n");
				wbid[j].write(i + " " + bidDistribution[i][j] + "\n");
			}
		}

		for (int j = 0; j < 9; j++) {
			wask[j].close();
			wbid[j].close();
		}
		
		Misc.println("average ask price by day");
		for (int i = 0; i < 4; i++) Misc.print(formatter.format(averageAskByDay[i]) + "\t");
		Misc.println();
		
		Misc.println("average bid price by day");
		for (int i = 0; i < 4; i++) Misc.print(formatter.format(averageBidByDay[i]) + "\t");
		Misc.println();
		
		Misc.println("average ask price by minute");
		for (int i = 0; i < 9; i++) Misc.print(formatter.format(averageAskByMinute[i]) + "\t");
		Misc.println();
		
		Misc.println("average bid price by minute");
		for (int i = 0; i < 9; i++) Misc.print(formatter.format(averageBidByMinute[i]) + "\t");
		Misc.println();
	} catch (Exception e) { e.printStackTrace(); }}
	
	/**
	 * Calculates hotel average by closing time and by type.
	 */
	public void analyzeHotel () {
		double[] averageByAuction = new double[8];
		double[] averageByClosingOrder = new double[8];
		
		for (int gameNo = 1; gameNo <= 165; gameNo++) {
			Misc.println(gameNo);
			final String fileToRead = "/pro/roxybot/2005/sjlee/data/history/final06/applet" + gameNo + ".log";
			
			parser.readAllocation = false;
			parser.readBid = false;
			parser.readCollection = false;
			parser.readPreference = false;
			parser.readScore = false;
			parser.readTransaction = false;
			
			try {
				parser.parse(fileToRead);
			} catch (IOException e) {
				Misc.println("## Scorer.score::" + fileToRead + " doesn't exist.");
				e.printStackTrace();
				continue;
			}
			
			for (int auc = 0; auc < 8; auc++) {
				averageByAuction[auc] += parser.hotelClosingPrice[auc] / 165;
			}
			
			for (int t = 1; t < 9; t++) {
				for (int auc = 0; auc < 8; auc++) {
					if (parser.hotelClosingTime[auc] == t) {
						averageByClosingOrder[t-1] += parser.hotelClosingPrice[auc] / 165;
					}
				}
			}
		}
		
		System.out.println("hotel average by auction");
		for (int i = 0; i < 8; i++) System.out.print(formatter.format(averageByAuction[i]) + "\t");
		System.out.println();
		
		System.out.println("hotel average by closing order");
		for (int i = 0; i < 8; i++) System.out.print(formatter.format(averageByClosingOrder[i]) + "\t");
		System.out.println();
	}
	
	// TODO
	public static void main(String[] args) {
		int fromID = 1;
		int toID = 224;
		// String directoryToWrite = "/pro/roxybot/2005/sjlee/data/history/final06/";
		// String directoryToWrite = "/pro/roxybot/2005/vnarodit/exp/8agent/server/";
		String directoryToWrite = "/pro/roxybot/2005/sjlee/experiment/8agent.attac.vs.nonattac.061026/server/";
		// String directoryToRead = directoryToWrite;
		String directoryToRead = directoryToWrite + "logs/games/";
		String[] agentNames = {"saa-t", "2000-t", "saa-f", "2002-t", "2000-f", "2002-f", "smu", "amu"}; // 200
		// String[] agentNames = {"RoxyBot", "Walverine", "WhiteDolphin", "SICS02", "Mertacor", "L-Agent", "kin_agent", "UTTA06"};
		// String[] agentNames = {"2000-f", "2000-t"}; // 206
		//String[] agentNames = {"2000-f", "2000-t", "smu", "evm"}; // 224
		// String[] agentNames = {"2000-t", "2000-f", "amu", "smu"}; // 269
		
		Scorer scorer = new Scorer(agentNames.length);
		// scorer.analyzeHotel();
		// scorer.analyzeEntertainment();
		// scorer.entertainmentKMeans();
		
		/*
		// Download logs from the host. 
		for (int gameID = fromID; gameID <= toID; gameID++) {
		 	scorer.downloadFromHost("tac1.sics.se", gameID); Misc.print(gameID + " ");
		 	if (gameID % 10 == 0) Misc.println();
		} /**/ // Uncomment this when you need data from sics.se server.
		
		// Read from logs. Once you read it, it's saved as files.
		scorer.readFromLogs (fromID, toID, directoryToRead, directoryToWrite, agentNames);
		
		// Read from files.
		scorer.readFromFile(directoryToWrite + "score.txt");
		scorer.readFromFile(directoryToWrite + "utility.txt");
		scorer.readFromFile(directoryToWrite + "cost.txt");
		
		// Print
		scorer.printStatistics();
		scorer.printBidInformation();
		scorer.runPairedTTest(agentNames);
		/**/
	}
}
