#!/bin/sh

rm -f com/botbox/util/*.class
rm -f com/botbox/html/*.class
rm -f se/sics/isl/inet/*.class
rm -f se/sics/isl/util/*.class
rm -f se/sics/tac/util/*.class
rm -f se/sics/tac/log/*.class
rm -f se/sics/tac/is/*.class
rm -f se/sics/tac/server/*.class
rm -f se/sics/tac/server/classic/*.class
rm -f se/sics/tac/line/*.class
rm -f se/sics/tac/solver/*.class



CP=.:lib/org.mortbay.jetty.jar:lib/javax.servlet.jar
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP com/botbox/util/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP com/botbox/html/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/isl/inet/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/isl/util/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/util/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/log/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/is/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/server/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/server/classic/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/line/*.java
/pro/java/linux/jdk1.4.1/bin/javac -classpath $CP se/sics/tac/solver/*.java
/pro/java/linux/jdk1.4.1/bin/javac -target 1.1 se/sics/tac/applet/*.java

jar cfm tacserver.jar manifest/TACServerManifest.txt com/botbox/util/*.class com/botbox/html/*.class se/sics/isl/inet/*.class se/sics/isl/util/*.class se/sics/tac/util/*.class se/sics/tac/log/*.class se/sics/tac/server/*.class se/sics/tac/server/classic/*.class se/sics/tac/line/*.class se/sics/tac/solver/*.class

jar cfm infoserver.jar manifest/InfoServerManifest.txt com/botbox/util/*.class com/botbox/html/*.class se/sics/isl/inet/*.class se/sics/isl/util/*.class se/sics/tac/util/*.class se/sics/tac/log/*.class se/sics/tac/is/*.class se/sics/tac/line/*.class se/sics/tac/solver/*.class

jar cf public_html/code/tacapplet.jar se/sics/tac/applet/*.class
